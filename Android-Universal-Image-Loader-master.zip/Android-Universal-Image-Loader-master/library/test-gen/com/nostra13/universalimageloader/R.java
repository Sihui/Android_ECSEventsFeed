package com.nostra13.universalimageloader;

public class R
{
    public static final class attr
    {
    }

    public static final class drawable
    {
    }

    public static final class id
    {
    }

    public static final class layout
    {
    }

    public static final class string
    {
    }
}